import Foundation
import CoreData

final class PersistenceController {
    static let shared = PersistenceController()

    let container: NSPersistentCloudKitContainer

    init(inMemory: Bool = false) {
        container = NSPersistentCloudKitContainer(name: "MoneyKeeperModel")

        if inMemory {
            let desc = NSPersistentStoreDescription(url: URL(fileURLWithPath: "/dev/null"))
            container.persistentStoreDescriptions = [desc]
        }

        if let desc = container.persistentStoreDescriptions.first {
            desc.setOption(true as NSNumber, forKey: NSPersistentStoreRemoteChangeNotificationPostOptionKey)
            desc.cloudKitContainerOptions = NSPersistentCloudKitContainerOptions(containerIdentifier: "iCloud.com.yourcompany.moneykeeper")
        }

        container.loadPersistentStores { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        }

        container.viewContext.automaticallyMergesChangesFromParent = true
        container.viewContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy

        // Run a cleanup of transactions older than 2 years on startup
        purgeTransactionsOlderThanYears(2)
    }

    /// Purge transactions older than `years` from the store (runs on background context)
    func purgeTransactionsOlderThanYears(_ years: Int) {
        let ctx = container.newBackgroundContext()
        ctx.perform {
            let fetch = NSFetchRequest<NSFetchRequestResult>(entityName: "TransactionEvent")
            let cutoff = Calendar.current.date(byAdding: .year, value: -years, to: Date()) ?? Date.distantPast
            fetch.predicate = NSPredicate(format: "date < %@", cutoff as NSDate)
            let request = NSBatchDeleteRequest(fetchRequest: fetch)
            do {
                try ctx.execute(request)
                try ctx.save()
                print("Purged transactions older than \(years) years (before \(cutoff))")
            } catch {
                print("Failed to purge old transactions: \(error)")
            }
        }
    }
}
