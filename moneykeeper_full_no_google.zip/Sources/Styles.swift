import SwiftUI

struct LiquidGlassCard<Content: View>: View {
    var content: () -> Content

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .fill(.ultraThinMaterial)
                .background(LinearGradient(gradient: Gradient(colors: [Color.white.opacity(0.06), Color.white.opacity(0.02)]), startPoint: .topLeading, endPoint: .bottomTrailing))
                .overlay(RoundedRectangle(cornerRadius: 20).stroke(.thinMaterial))
                .shadow(color: Color.black.opacity(0.08), radius: 8, x: 0, y: 6)
            content()
                .padding()
        }
        .transition(.move(edge: .bottom).combined(with: .opacity))
        .animation(.spring(), value: UUID())
    }
}
