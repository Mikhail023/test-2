import Foundation
import AuthenticationServices
import SwiftUI
import CryptoKit
import os

@MainActor
final class SignInWithAppleManager: NSObject, ObservableObject {
    static let shared = SignInWithAppleManager()

    @Published var isSignedIn: Bool = false
    @Published var userIdentifier: String? = nil
    @Published var userFullName: String? = nil
    @Published var userEmail: String? = nil

    private var currentNonce: String?

    func startSignInWithAppleFlow() {
        let nonce = Self.randomNonceString()
        currentNonce = nonce
        let request = ASAuthorizationAppleIDProvider().createRequest()
        request.requestedScopes = [.fullName, .email]
        request.nonce = Self.sha256(nonce)

        let controller = ASAuthorizationController(authorizationRequests: [request])
        controller.delegate = self
        controller.presentationContextProvider = self
        controller.performRequests()
    }

    private static func randomNonceString(length: Int = 32) -> String {
        precondition(length > 0)
        let charset: [Character] =
            Array("0123456789ABCDEFGHIJKLMNOPQRSTUVXYZabcdefghijklmnopqrstuvwxyz-._")
        var result = ""
        var remainingLength = length

        while remainingLength > 0 {
            let randoms: [UInt8] = (0..<16).map { _ in UInt8.random(in: 0...255) }
            randoms.forEach { num in
                if remainingLength == 0 { return }
                if num < charset.count {
                    result.append(charset[Int(num) % charset.count])
                    remainingLength -= 1
                }
            }
        }
        return result
    }

    private static func sha256(_ input: String) -> String {
        let inputData = Data(input.utf8)
        let hashed = SHA256.hash(data: inputData)
        return hashed.compactMap { String(format: "%02x", $0) }.joined()
    }
}

extension SignInWithAppleManager: ASAuthorizationControllerDelegate {
    func authorizationController(controller: ASAuthorizationController, didCompleteWithAuthorization authorization: ASAuthorization) {
        if let appleIDCredential = authorization.credential as? ASAuthorizationAppleIDCredential {
            let userId = appleIDCredential.user
            self.userIdentifier = userId
            self.userFullName = [appleIDCredential.fullName?.givenName, appleIDCredential.fullName?.familyName].compactMap{ $0 }.joined(separator: " ")
            self.userEmail = appleIDCredential.email
            self.isSignedIn = true
            os_log("Signed in with Apple: %{public}s", userId)
        }
    }

    func authorizationController(controller: ASAuthorizationController, didCompleteWithError error: Error) {
        os_log("Sign in with Apple failed: %{public}s", error.localizedDescription)
        self.isSignedIn = false
    }
}

extension SignInWithAppleManager: ASAuthorizationControllerPresentationContextProviding {
    func presentationAnchor(for controller: ASAuthorizationController) -> ASPresentationAnchor {
        #if os(iOS)
        return UIApplication.shared.windows.first { $0.isKeyWindow } ?? UIWindow()
        #elseif os(macOS)
        return NSApplication.shared.windows.first ?? NSWindow()
        #else
        return UIWindow()
        #endif
    }
}
