import SwiftUI
import CoreData

@main
struct MoneyKeeperApp: App {
    let persistenceController = PersistenceController.shared
    @StateObject var auth = SignInWithAppleManager.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
                .environmentObject(auth)
        }
    }
}
