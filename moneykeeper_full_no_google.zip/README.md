MoneyKeeper — Starter Project (No Google Sign-In)
Generated: 2025-09-22T16:13:21.923874Z

This bundle contains a SwiftUI multiplatform starter app with:
- Core Data + CloudKit-ready container
- Sign in with Apple implementation
- Liquid-glass UI helpers, history, analytics, settings
- Localizations (ru/en)
- Automatic purge of transactions older than 2 years at startup
- NO Google or Firebase code included (removed as requested)

To open in Xcode:
1) Create a new Xcode App (SwiftUI) project (or open an existing one).
2) Copy the 'Sources' folder and 'MoneyKeeperModel.xcdatamodeld' into your Xcode project directory.
3) Add the model to the project navigator, set Codegen to 'Class Definition' or generate NSManagedObject subclasses.
4) Enable iCloud -> CloudKit in Signing & Capabilities and set your container identifier to match Persistence.swift.
5) Run the app on iPhone/iPad/Mac targets. Adjust bundle identifier and team in Signing settings.

If you want, I can now produce a ready-to-open '.xcodeproj' that references these files automatically (I can create a minimal project file). Would you like that?
